export interface Signin{
    "_id":string;
    "email":string;
    "isAdmin":boolean;
    "image":string;
    "token":string;
}