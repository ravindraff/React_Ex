DOM
---
    DOM Stands for Document Object Model.

    DOM Acting as interface Between "HTML with CSS" and "JavaScript".

    By Using DOM, JavaScript can manipulate the HTML Elements.

    when ever we execute HTML with Browser Engine, automatically Browser Engine will create JavaScript Object (DOM Object / Real DOM Object).

    in JavaScript Object, all the HTML Elements will be arranged in Tree Structure.

    Tree Structure Technically Called as DOM Tree Structure.

    Traversing over DOM Object, Technically Called as DOM Tree Traversing.




