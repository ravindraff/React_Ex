console.log("welcome to ashokit");          //welcome to ashokit
console.log( 10+10 );                       //20
console.log( 10 + "10" );                    //1010
console.log( 10 - "10" );                   //0
console.log( 10 * "10" );                   //100
console.log( 10 / "10" );                   //1
console.log( 10 + +"10" );                  //20
console.log( 10>9>8 );                     //false
console.log( 0.1+0.2 == 0.3);             //false



   