// const calc = (num1,num2,num3)=>{
//     return num1+num2+num3;
// };
// console.log( calc(10,10,10) );


// const calc = (num1)=>{
//     return (num2)=>{
//         return (num3)=>{
//             return num1+num2+num3;
//         }
//     }
// };
// console.log( calc(10)(10)(10) );                //30


