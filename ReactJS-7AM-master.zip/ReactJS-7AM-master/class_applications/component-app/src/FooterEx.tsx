import React from "react";
import { Typography } from "@material-ui/core";
export default function FooterEx(){
    return(
        <Typography color="textSecondary" variant="h6" align="right">
            copyright@ashokit.in
        </Typography>
    )
};