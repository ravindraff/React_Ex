export interface Product{
    "_id":string;
    "name":string;
    "category":string;
    "image":string;
    "brand":string;
    "rating":number;
    "numReviews":number;
    "description":string;
};