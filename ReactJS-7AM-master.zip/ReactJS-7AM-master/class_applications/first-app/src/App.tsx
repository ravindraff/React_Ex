import React from 'react';
const App = (props:any)=>{
  return(
    <div>
      Hello
    </div>
  )
}
export default App;