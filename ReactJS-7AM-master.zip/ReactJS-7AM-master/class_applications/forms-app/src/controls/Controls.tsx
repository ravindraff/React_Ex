import Input from "./Input";
const Controls = {
    Input
};
export default Controls;