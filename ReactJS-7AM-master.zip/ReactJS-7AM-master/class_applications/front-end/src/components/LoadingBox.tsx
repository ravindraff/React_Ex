import React from "react";

export class LoadingBox extends React.Component<{},{}>{
    render(){
        return(
            <div>
                <i className="fa fa-spinner fa-spin"></i> Loading
            </div>
        )
    }
};

































// import React from "react";
// export class LoadingBox extends React.Component<{},{}>{
//     render(){
//         return(
//             <div>
//                 <i className="fa fa-spinner fa-spin"></i> Loading...
//             </div>
//         )
//     }
// }