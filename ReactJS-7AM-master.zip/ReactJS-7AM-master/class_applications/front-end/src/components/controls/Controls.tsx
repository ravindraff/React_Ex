import Input from "./Input";
import RadioEx from "./RadioGroup";

const Controls = {
    Input,
    RadioEx
};

export default Controls;