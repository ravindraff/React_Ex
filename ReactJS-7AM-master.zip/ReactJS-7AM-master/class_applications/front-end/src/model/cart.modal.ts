export interface CartModal{
    "name":string;
    "image":string;
    "price":number;
    "countInStock":number;
    "_id":string;
};