export default interface registrationModal{
    registration:string;
};