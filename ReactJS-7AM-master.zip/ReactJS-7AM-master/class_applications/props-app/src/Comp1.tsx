import React from "react";
import {Comp2} from "./Comp2";
export function Comp1():any{
    return(
        <React.Fragment>
            <Comp2 key1="Hello_1"/>
        </React.Fragment>
    )
};