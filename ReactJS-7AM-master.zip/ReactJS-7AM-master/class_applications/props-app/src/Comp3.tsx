import React from "react";
export function Comp3(props:any):any{
    return(
        <React.Fragment>
            <h1>{props.key1}</h1>
        </React.Fragment>
    )
};