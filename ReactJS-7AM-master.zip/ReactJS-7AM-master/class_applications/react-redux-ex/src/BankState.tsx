export default interface BankState{
    bal : any;
};