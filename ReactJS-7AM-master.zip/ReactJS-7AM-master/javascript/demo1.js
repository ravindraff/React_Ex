"use strict";
//modules are "custom development by developer" in project.
//modules have internal scope (with in the project we can use).
exports.__esModule = true;
;
