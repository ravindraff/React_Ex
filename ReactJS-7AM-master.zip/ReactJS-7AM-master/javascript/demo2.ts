/*
    import {wish} from "./demo1";
    console.log(wish);
*/


/*
    // import {var_one} from "./demo1";
    // import {var_two} from "./demo1";
    // import {var_three} from "./demo1";
    // console.log(var_one, var_two,var_three );    //Hello_1 Hello_2 Hello_3


    import * as my_var from "./demo1";
    console.log(my_var.var_one,
                my_var.var_two,
                my_var.var_three);       //Hello_1 Hello_2 Hello_3

    import {var_one,var_two,var_three} from "./demo1";
    console.log(var_one,var_two,var_three);    //Hello_1 Hello_2 Hello_3
*/



/*
    import fun_one from "./demo1";
    console.log( fun_one() );
*/


/*
    //import { fun_one,fun_two,fun_three } from "./demo1";
    import * as my_fun from "./demo1"; 
    console.log( my_fun.fun_one(),
                my_fun.fun_two(),
                my_fun.fun_three() );     //ReactJS NodeJS MongoDB
*/


/*
    import obj from "./demo1";
    console.log(obj);
*/


/*
    import { class_one } from "./demo1";
    let obj:class_one = new class_one("Hello");
    console.log(obj.var_one);
*/

/*
    import interface1 from "./demo1";
    let obj:interface1 = {
        var_one : "Hello_1",
        getVarOne : ():string=>{
            return obj.var_one;
        }
    };

    class class_one implements interface1{
        var_one:string = "Hello_2";
        getVarOne():string{
            return this.var_one;
        };
    };

    console.log( obj.var_one, obj.getVarOne() );

    let obj1:class_one = new class_one();
    console.log( obj1.var_one, obj1.getVarOne() );
*/













































