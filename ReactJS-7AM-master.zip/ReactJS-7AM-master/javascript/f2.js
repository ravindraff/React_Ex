"use strict";
exports.__esModule = true;
exports.my_fun = void 0;
var f1_1 = require("./f1");
function my_fun() {
    return f1_1.sub;
}
exports.my_fun = my_fun;
;
