import { sub } from "./f1";
export function my_fun():string{
    return sub;
};