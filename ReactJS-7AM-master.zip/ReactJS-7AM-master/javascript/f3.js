"use strict";
exports.__esModule = true;
exports.class_one = void 0;
var f2_1 = require("./f2");
var class_one = /** @class */ (function () {
    function class_one() {
        this.my_var = f2_1.my_fun();
    }
    return class_one;
}());
exports.class_one = class_one;
;
