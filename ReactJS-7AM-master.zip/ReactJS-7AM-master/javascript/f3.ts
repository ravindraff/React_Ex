import {my_fun} from "./f2";

export class class_one{
    my_var:string = my_fun();
};