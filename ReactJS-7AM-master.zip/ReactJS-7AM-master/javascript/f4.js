"use strict";
exports.__esModule = true;
var f3_1 = require("./f3");
console.log(new f3_1.class_one().my_var);
