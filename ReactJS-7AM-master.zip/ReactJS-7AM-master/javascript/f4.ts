import { class_one } from "./f3";
console.log( new class_one().my_var );   //Hello