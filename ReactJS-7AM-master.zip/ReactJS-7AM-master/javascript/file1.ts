/*
    namespace AshokIT{
        export const sub:string = "ReactJS";
        export namespace SambaIT{
            export function getWish():string{
                return `Welcome to ${sub}`;
            };
        };
    };
*/


namespace namespace1{
    export const var_one:any = "Hello_1";
    export function fun_one():any{
        return "Hello_2";
    };
    export const obj:any = {
        var_three : "Hello_3"
    };
    export class class_one{
        var_four:any="Hello_4"
    };
    export interface interface1{
        var_five:any;
    };
};

















