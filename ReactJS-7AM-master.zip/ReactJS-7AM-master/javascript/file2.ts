/*
    /// <reference path="file1.ts" />
    console.log( AshokIT.sub,
                AshokIT.SambaIT.getWish() );
*/


/// <reference path="file1.ts" />

let obj:namespace1.interface1 = {
    var_five : "Hello_5"
};

console.log( namespace1.var_one,
             namespace1.fun_one(),
             namespace1.obj.var_three,
             new namespace1.class_one().var_four,
             obj.var_five );





