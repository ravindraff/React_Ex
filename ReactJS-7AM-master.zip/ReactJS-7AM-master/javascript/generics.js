//function fun_one<string>(arg1:string):string{}
;
var obj = {
    arg1: "Hello_1"
};
console.log(obj.arg1);
