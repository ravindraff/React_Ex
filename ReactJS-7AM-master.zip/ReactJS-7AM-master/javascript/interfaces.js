//if we know only declarations but we dont know implementations then we will choose interfaces
//we will declare interfaces by using "interface" keyword.
//implentation provided by either class or json 
;
;
;
;
var obj = {
    fun_one: function () {
        return "Hello";
    }
};
console.log(obj.fun_one());
