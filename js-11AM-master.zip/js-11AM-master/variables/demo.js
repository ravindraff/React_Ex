console.log("welcome to javascript");                   //welcome to javascript
console.log( 10+"10" );                                 //1010
console.log( 10+ +"100");                               //110
console.log( +"10" + +"10" + +"10");                    //30
console.log( 10+10+10+ +"10" );                         //40
console.log( 10-"10");                                  //0
console.log( 10*"10" );                                 //100
console.log( 10/"10");                                  //1
console.log( "10"/"10" );                               //1
console.log( "10"/0 );                                  //Infinity
console.log( "one"/"0" );                               //NaN
console.log( 10>9>8 );                                  //false
             