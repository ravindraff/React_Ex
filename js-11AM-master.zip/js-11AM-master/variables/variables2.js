//Symbol
//Symbol is the datatype
//ES6
//Secuirity
var v1 = Symbol("Hello");
var v2 = Symbol("Hello");
console.log( v1 == v2 );                                            //false
console.log( Symbol.for("Welcome") == Symbol.for("Welcome") );      //true


//bigint
//ES6
// >2^53-1 range
//suffix with "n"
var n1 = 10101139710397123097021702194721047209472094709700937240329740239740239740923740397423097423097403297432073207n;
console.log(n1);




















