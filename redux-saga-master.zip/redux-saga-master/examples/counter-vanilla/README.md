# Run locally
Open `index.html` file in a browser