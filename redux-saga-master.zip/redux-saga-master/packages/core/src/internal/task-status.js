export const RUNNING = 0
export const CANCELLED = 1
export const ABORTED = 2
export const DONE = 3
